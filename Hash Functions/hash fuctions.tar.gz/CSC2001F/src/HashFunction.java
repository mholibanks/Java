import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class HashFunction {
	int tableSize = 20011;
	/**
	 * This is the worst case method which returns 1 for every value in table
	 * @param key
	 * @return
	 */
	public int hashWorstCase(String key){
		return 1;
	}
	/**
	 * This is hash function 1 which adds together unicode values and mod tablesize 
	 * @param key
	 * @return
	 */
	public int hash1 ( String key )
	{
		 int hashVal = 0;
	
		 for( int i = 0; i < key.length(); i++ )
		 hashVal += key.charAt(i);
		 
		return Math.abs(hashVal % tableSize);
	}
	/**
	 * This is hash function 2 adds unicode values and mod tablesize also multiplies/shift each char by some value
	 * @param key
	 * @return
	 */
	public int hash2 (String key )
	{
		int hashVal = 0;
	
		 for( int i = 0; i < key.length(); i++ )
		 hashVal = (37 * hashVal) + key.charAt(i);
		 if(hashVal<0){
			 hashVal = hashVal + tableSize;}
		 return Math.abs(hashVal % tableSize);
	}
	/**
	 * This is a custom built hash function meant to be reasonable to solve problem of collision to some degree
	 * @param key
	 * @return
	 */
	public int myHash (String key)
	{
		int hashVal = 0;
		
		for(int i = 0; i < key.length(); i++)
			hashVal = 71*hashVal+key.charAt(i);
			
			if(hashVal<0){
				 hashVal = hashVal + tableSize;}
			 return Math.abs(hashVal % tableSize);
	}
	public static void main(String[] args) throws IOException{
		ArrayList<Integer> worstCaseF = new ArrayList<Integer>();
		ArrayList<Integer> hashValuesHash1 = new ArrayList<Integer>();
		ArrayList<Integer> hashValuesHash2 = new ArrayList<Integer>();
		ArrayList<Integer> hashValuesMyhash = new ArrayList<Integer>();
		ArrayList<Double> probability =  new ArrayList<Double>();
		ArrayList<Double> entropy = new ArrayList<Double>();
		ArrayList<String> data = new ArrayList<String>();
		String file_name = "/home/banks/Documents/CSC2001F/src/testdata";
		double sum = 0;
		
		BufferedReader br = new BufferedReader(new FileReader(file_name));
		try{
			String line = br.readLine();
			while(line != null){
			
				data.add( line.toString().split("\\|")[2]);
				line = br.readLine();
			}} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{br.close();}
		//System.out.println(data.get(1)); debugging purposes
		
		HashFunction hashF = new HashFunction();
		int i = 0;
		
		System.out.println("\nWorstCase\n");
		
		for(i = 0; i < data.size(); i++){
			worstCaseF.add(hashF.hashWorstCase(data.get(i)));
			//System.out.println(worstCaseF.get(i));
		}
		
		int counter = 0;
		for(i = 0; i< hashF.tableSize; i++ ){
			
			for(int j = 0; j< worstCaseF.size(); j++){
				if(worstCaseF.get(j) == i){
					counter++;
				}
			}
			probability.add((double)counter/hashF.tableSize);
			counter = 0;
		}
		
		for(int j = 0; j<probability.size(); j++){
		//System.out.println(probability.get(j));
		}
		for(int j= 0; j<worstCaseF.size();j++){
			if(probability.get(j)>0){
			entropy.add(Math.abs(probability.get(j)*Math.log(probability.get(j))));
			//System.out.println(Math.abs(probability.get(j)*Math.log(probability.get(j))));

			}
		}
		for(int j = 0; j<entropy.size();j++){
			sum = sum + entropy.get(j);
		}
		System.out.println(sum);

		
		System.out.println("\nHash1\n");
		sum = 0;
		counter = 0;
		probability.clear();
		entropy.clear();
		
		
		for(i = 0; i < data.size(); i++){
			hashValuesHash1.add(hashF.hash1(data.get(i)));
			//System.out.println(hashValuesHash1.get(i));
		}
		for(i = 0; i< hashF.tableSize; i++ ){
			
			for(int j = 0; j< hashValuesHash1.size(); j++){
				if(hashValuesHash1.get(j) == i){
					counter++;
				}
			}
			probability.add((double)counter/hashF.tableSize);
			counter = 0;
		}
		
		for(int j = 0; j<probability.size(); j++){
		//System.out.println(probability.get(j));
		}
		for(int j= 0; j<hashValuesHash1.size();j++){
			if(probability.get(j)>0){
			entropy.add(Math.abs(probability.get(j)*Math.log(probability.get(j))));
			//System.out.println(Math.abs(probability.get(j)*Math.log(probability.get(j))));

			}
		}
		for(int j = 0; j<entropy.size();j++){
			sum = sum + entropy.get(j);
		}
		System.out.println(sum);
		sum = 0;
		counter = 0;
		probability.clear();
		entropy.clear();
		
		System.out.println("\nHash2\n");
		for(i = 0; i <data.size(); i++){
			hashValuesHash2.add(hashF.hash2(data.get(i)));
			//System.out.println(hashValuesHash2.get(i));
		}


		for(i = 0; i< hashF.tableSize; i++ ){
			
			for(int j = 0; j< hashValuesHash2.size(); j++){
				if(hashValuesHash2.get(j) == i){
					counter++;
				}
			}
			probability.add((double)counter/hashF.tableSize);
			counter = 0;
		}
		
		for(int j = 0; j<probability.size(); j++){
		//System.out.println(probability.get(j));
		}
		for(int j= 0; j<hashValuesHash2.size();j++){
			if(probability.get(j)>0){
			entropy.add(Math.abs(probability.get(j)*Math.log(probability.get(j))));
			//System.out.println(Math.abs(probability.get(j)*Math.log(probability.get(j))));

			}
		}
		for(int j = 0; j<entropy.size();j++){
			sum = sum + entropy.get(j);
		}
		System.out.println(sum);
		sum = 0;
		counter = 0;
		probability.clear();
		entropy.clear();
		
		System.out.println("\nmyHashF\n");
	
		for(i = 0; i < data.size(); i++){
			hashValuesMyhash.add(hashF.myHash(data.get(i)));
			//System.out.println(hashValuesHash1.get(i));
		}
		for(i = 0; i< hashF.tableSize; i++ ){
			
			for(int j = 0; j< hashValuesMyhash.size(); j++){
				if(hashValuesMyhash.get(j) == i){
					counter++;
				}
			}
			probability.add((double)counter/hashF.tableSize);
			counter = 0;
		}
		
		for(int j = 0; j<probability.size(); j++){
		//System.out.println(probability.get(j));
		}
		for(int j= 0; j<hashValuesMyhash.size();j++){
			if(probability.get(j)>0){
			entropy.add(Math.abs(probability.get(j)*Math.log(probability.get(j))));
			//System.out.println(Math.abs(probability.get(j)*Math.log(probability.get(j))));

			}
		}
		for(int j = 0; j<entropy.size();j++){
			sum = sum + entropy.get(j);
		}
		System.out.println(sum);
	}
}
		
	


